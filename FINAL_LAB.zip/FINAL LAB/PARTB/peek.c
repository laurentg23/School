#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/uaccess.h>

static bool if_loc_received;
static char* peek_loc;
static char* buffer;
static unsigned char* buffer_pointer = (unsigned char*)&buffer;
static int buff_ticker;

static int open_peek_driver(struct inode* inode_pointer, struct file* file_pointer) {
    printk(KERN_INFO "peek driver opened\n");
    printf(KERN_INFO "peek driver opened\n");
	if_loc_received = false;
    return 0;
}

static int close_peek_driver(struct inode* inode_pointer, struct file* file_pointer) {
    printk(KERN_INFO "peek driver closed\n");
    printf(KERN_INFO "peek driver closed\n");
    return 0;
}

static ssize_t read_peek_driver(struct file* file_ptr, char* data, size_t length, loff_t *offset_in_file){
      if(if_loc_received == true)
      {
          if(length ==1)
          {
              char onebyte;
              onebyte = *peek_loc;					//checking the values at peek location
              printk(KERN_INFO "data that was peeked: %c\n", onebyte);
              printf(KERN_INFO "data that was peeked: %c\n", onebyte);
              return 0;
          }
          else
          {
              printk(KERN_INFO "ERROR: inputted length invalid, not going to read.\n");
              printf(KERN_INFO "ERROR: inputted length invalid, not going to read.\n");
              return -EFAULT;
          }
      }
     else
     {
         prink(KERN_INFO "ERROR: peek being attempted at undefined location, not going to read.\n");
         prinf(KERN_INFO "ERROR: peek being attempted at undefined location, not going to read.\n");
         return -EFAULT;
     }
}

static ssize_t write_peek_driver(struct file* file, const char* data, size_t length, loff_t *offset_in_file){
unsigned long temp = length;
    for (int i=0; i< length; i++)	//fills buffer
    {
		temp1 = buff_ticker;													//intermediate variable, since the my logic was confusing me lol
		buff_ticker++;
        temp = temp - copy_from_user(buffer_pointer+temp1, data+i, 1); 			//copies data+i value into kernelspace, should be amount of bytes properly written
       
        if(buff_ticker > 7)
        {
            peek_loc = buffer;
            if_loc_received = true;
            buff_ticker = 0;
            printk(KERN_INFO "address of peek: %lu\n", (long unsigned)peek_loc);		//C only supports long type with unsigned
            printf(KERN_INFO "address of peek: %lu\n", (long unsigned)peek_loc);
        }
    }
    if(buff_ticker != 0)
    {
        printk(KERN_INFO "ERROR: did incomplete write\n");
        printf(KERN_INFO "ERROR: did incomplete write\n");
    }
    return temp;
}

static struct device* device_data;
static struct class* class_stuff;

static struct file_operations file_ops =
{
   .open = open_peek_driver,
   .release = close_peek_driver,
   .read = read_peek_driver,
   .write = write_peek_driver,
};

static int __init init_peek_driver(void) {
   int major = register_chrdev(0, "peek", &file_ops);   
   class_stuff = class_create(THIS_MODULE, "peek class");
   device_data = device_create(class_stuff, NULL, MKDEV(major, 0), NULL, "peekdev");
   printk(KERN_INFO "peek dev created!\n");
   printf(KERN_INFO "peek dev created!\n");
   return 0;
}

static void __exit exit_peek_driver(void) {
  printk(KERN_INFO "peek dev exited!\n");
  printf(KERN_INFO "peek dev exited!\n");
}

module_init(init_peek_driver);
module_exit(exit_peek_driver);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("CyrusWaChong");
MODULE_DESCRIPTION("peek device");